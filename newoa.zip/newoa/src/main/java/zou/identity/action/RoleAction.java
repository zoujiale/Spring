package zou.identity.action;

import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import zou.identity.domain.Role;
import zou.identity.service.RoleService;

@Controller
@RequestMapping("/role")
public class RoleAction {
	
	@Resource
	RoleService roleservice;
	/**
	 * 拿到全部角色信息
	 * @return
	 */
	
	@GetMapping
	public ModelAndView getAllRole(@RequestParam(value = "findContent",
			required = false		)String findContent) {
		
		if ("".equals(findContent)) {
			findContent = null;
		}
		List<Role> roles = roleservice.findContent(findContent);
		
		ModelAndView modelAndView = new ModelAndView();
		modelAndView.addObject("Role", roles);
		
		modelAndView.addObject("keyword",findContent);
		modelAndView.setViewName("role/roleoperation");
		return modelAndView;
	}
	
	
}
