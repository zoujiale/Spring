package zou.common.dao;

import org.springframework.orm.hibernate5.HibernateOperations;

public interface ShareDao extends HibernateOperations{

}
