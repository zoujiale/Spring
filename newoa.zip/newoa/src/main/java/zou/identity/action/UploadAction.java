package zou.identity.action;

public class UploadAction {

}
